# betterImageStorageObject
 better Image Storage Object Class for storing imageArrays in memory
